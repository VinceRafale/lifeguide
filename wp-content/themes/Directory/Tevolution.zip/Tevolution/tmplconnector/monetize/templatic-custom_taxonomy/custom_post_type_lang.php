<?php
define('CUSTOM_MENU_CAT_LABEL',__('Categories',DOMAIN));
define('CUSTOM_MENU_CAT_TITLE',__('Categories',DOMAIN));
define('CUSTOM_MENU_SIGULAR_CAT',__('Category',DOMAIN));
define('CUSTOM_MENU_CAT_SEARCH',__('Search category',DOMAIN));
define('CUSTOM_MENU_CAT_POPULAR',__('Popular categories',DOMAIN));
define('CUSTOM_MENU_CAT_ALL',__('All categories',DOMAIN));
define('CUSTOM_MENU_CAT_PARENT',__('Parent category',DOMAIN));
define('CUSTOM_MENU_CAT_PARENT_COL',__('Parent category:',DOMAIN));
define('CUSTOM_MENU_CAT_EDIT',__('Edit category',DOMAIN));
define('CUSTOM_MENU_CAT_UPDATE',__('Update category',DOMAIN));
define('CUSTOM_MENU_CAT_ADDNEW',__('Add new category',DOMAIN));
define('CUSTOM_MENU_CAT_NEW_NAME',__('New category name',DOMAIN));
define('CUSTOM_MENU_TAG_LABEL',__('Tags',DOMAIN));
define('CUSTOM_MENU_TAG_TITLE',__('Tags',DOMAIN));
define('CUSTOM_MENU_TAG_NAME',__('Tags',DOMAIN));
define('CUSTOM_MENU_TAG_SEARCH',__('Tags',DOMAIN));
define('CUSTOM_MENU_TAG_POPULAR',__('Popular tags',DOMAIN));
define('CUSTOM_MENU_TAG_ALL',__('All tags',DOMAIN));
define('CUSTOM_MENU_TAG_PARENT',__('Parent tags',DOMAIN));
define('CUSTOM_MENU_TAG_PARENT_COL',__('Parent tags:',DOMAIN));
define('CUSTOM_MENU_TAG_EDIT',__('Edit tags',DOMAIN));
define('CUSTOM_MENU_TAG_UPDATE',__('Update tags',DOMAIN));
define('CUSTOM_MENU_TAG_ADD_NEW',__('Add new tags',DOMAIN));
define('CUSTOM_MENU_TAG_NEW_ADD',__('New tag name',DOMAIN));
define('FLD_REQUIRED_TEXT',__('*',DOMAIN));

define('GRID_VIEW_TEXT',__('Grid view',DOMAIN));
define('LIST_VIEW_TEXT',__('List view',DOMAIN));
?>